package abstractMethod01;

public class 고양이 extends 동물 {
	void 울어보세요() {
		System.out.println("나는 고양이! 야옹! 야옹!");
	}
}