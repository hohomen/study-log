package abstractMethod01;

public class 동물 {
	void 울어보세요() {
		System.out.println("나는 동물! 어떻게 울어야 하나요?");
	}
}