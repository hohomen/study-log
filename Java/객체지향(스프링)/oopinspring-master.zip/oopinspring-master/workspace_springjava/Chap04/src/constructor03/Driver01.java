package constructor03;

public class Driver01 {
	public static void main(String[] args) {
		동물 뽀로로 = new 동물("뽀로로");
	}
}