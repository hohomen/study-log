package constructor02;

public class Driver {
	public static void main(String[] args) {
		동물 뽀로로 = new 동물();
	}
}