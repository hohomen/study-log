package constructor02;

public class 동물 {
	public 동물() { }
}