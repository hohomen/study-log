package staticBlock;

public class Driver04 {
	public static void main(String[] args) {
		System.out.println("main 메서드 시작!");
		동물 뽀로로 = new 동물();
		동물 피카츄 = new 동물();
	}
}