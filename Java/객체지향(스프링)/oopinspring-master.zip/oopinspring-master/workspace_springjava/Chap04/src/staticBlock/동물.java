package staticBlock;

public class 동물 {
	static {
		System.out.println("동물 클래스 레디 온!");
	}
}