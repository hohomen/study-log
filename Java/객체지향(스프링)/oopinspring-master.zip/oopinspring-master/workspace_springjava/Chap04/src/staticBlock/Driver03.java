package staticBlock;

public class Driver03 {
	public static void main(String[] args) {
		System.out.println("main 메서드 시작!");
		동물 뽀로로 = new 동물();
	}
}