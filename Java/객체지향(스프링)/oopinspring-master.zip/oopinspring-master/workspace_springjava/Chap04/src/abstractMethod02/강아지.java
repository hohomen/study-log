package abstractMethod02;

public class 강아지 extends 동물 {
	void 울어보세요() {
		System.out.println("나는 강아지! 멍! 멍!");
	}
}