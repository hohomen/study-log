package abstractMethod02;

public class 병아리 extends 동물 {
	void 울어보세요() {
		System.out.println("나는 병아리! 삐약! 삐약!");
	}
}