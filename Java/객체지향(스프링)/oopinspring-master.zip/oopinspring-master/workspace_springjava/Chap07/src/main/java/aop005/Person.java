package aop005;

public interface Person {
	void runSomething();
}
