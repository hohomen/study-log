package aop003;

public interface Person {
	void runSomething();
}
