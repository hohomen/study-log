package aop002;

public interface Person {
	void runSomething();
}