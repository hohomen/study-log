package expert001_01;

public class Driver {
	public static void main(String[] args) {
		Car car = new Car();

		System.out.println(car.getTireBrand());
	}
}