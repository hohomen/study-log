package aop006;

public interface Person {
	void runSomething();
}
