package expert002;

public interface Tire {
	String getBrand();
}