package aop004;

public interface Person {
	void runSomething();
}
