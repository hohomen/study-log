package aop005;

public class Girl implements Person {
	public void runSomething() {
		System.out.println("요리를 한다.");
	}
}