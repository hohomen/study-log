package expert001_03;

public interface Tire {
	String getBrand();
}