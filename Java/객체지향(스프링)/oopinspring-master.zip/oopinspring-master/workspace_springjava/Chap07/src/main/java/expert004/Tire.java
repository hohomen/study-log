package expert004;

public interface Tire {
	String getBrand();
}