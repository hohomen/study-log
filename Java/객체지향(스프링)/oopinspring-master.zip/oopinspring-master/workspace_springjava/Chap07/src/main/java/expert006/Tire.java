package expert006;

public interface Tire {
	String getBrand();
}