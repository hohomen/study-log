package expert001_02;

public interface Tire {
	String getBrand();
}