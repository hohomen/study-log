package expert002;

public class KoreaTire implements Tire {
	public String getBrand() {
		return "코리아 타이어";
	}
}