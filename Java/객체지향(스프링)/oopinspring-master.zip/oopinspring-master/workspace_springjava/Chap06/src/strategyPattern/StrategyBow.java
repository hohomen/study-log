package strategyPattern;

public class StrategyBow implements Strategy {
	@Override
	public void runStrategy() {
		System.out.println("슝.. 쐐액.. 쇅, 최종 병기");
	}
}