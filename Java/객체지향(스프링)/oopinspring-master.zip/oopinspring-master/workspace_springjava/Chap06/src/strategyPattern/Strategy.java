package strategyPattern;

public interface Strategy {
	public abstract void runStrategy();
}