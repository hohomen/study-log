package adapterPattern;

public class ServiceA {
	void runServiceA() {
		System.out.println("ServiceA");
	}
}