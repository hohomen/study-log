package adapterPattern;

public class ServiceB {
	void runServiceB() {
		System.out.println("ServiceB");
	}
}