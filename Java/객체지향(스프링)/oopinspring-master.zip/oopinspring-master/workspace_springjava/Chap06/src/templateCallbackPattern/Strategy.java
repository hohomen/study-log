package templateCallbackPattern;

public interface Strategy {
	public abstract void runStrategy();
}