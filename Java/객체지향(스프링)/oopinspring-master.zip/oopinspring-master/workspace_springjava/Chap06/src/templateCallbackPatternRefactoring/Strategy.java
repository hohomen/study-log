package templateCallbackPatternRefactoring;

public interface Strategy {
	public abstract void runStrategy();
}