package decoratorPattern;

public interface IService {
	public abstract String runSomething();
}