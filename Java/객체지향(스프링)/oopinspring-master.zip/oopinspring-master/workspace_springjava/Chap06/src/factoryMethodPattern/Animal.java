package factoryMethodPattern;

public abstract class Animal {
	// 추상 팩터리 메서드
	abstract AnimalToy getToy();
}