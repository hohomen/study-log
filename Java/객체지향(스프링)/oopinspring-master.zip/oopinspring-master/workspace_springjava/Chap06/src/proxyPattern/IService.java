package proxyPattern;

public interface IService {
	String runSomething();
}