package srp.good;

public class 남자 {
	String 군번;
}