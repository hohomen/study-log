package poorSuperClass;

public class 사람 {
	String 이름;
	
	void 먹다() {
		System.out.println(이름 + " 식사 중");
	}
}