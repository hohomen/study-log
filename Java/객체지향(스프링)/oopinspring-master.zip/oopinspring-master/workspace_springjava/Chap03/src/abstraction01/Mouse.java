package abstraction01;

public class Mouse {
	public String name;
	public int age;
	public int countOfTail;

	public void sing() {
		System.out.println(name + " 찍찍!!!");
	}
}