package inheritance02;

public class 포유류 extends 동물 {
	포유류() {
		myClass = "포유류";
	}
}