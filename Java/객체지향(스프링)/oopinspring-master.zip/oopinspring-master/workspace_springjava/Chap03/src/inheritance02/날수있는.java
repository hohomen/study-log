package inheritance02;

public interface 날수있는 {
	void fly();
}