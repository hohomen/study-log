package inheritance01;

public class 참새 extends 조류 {
	참새() {
		myClass = "참새";
	}
}