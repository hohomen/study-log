package inheritance01;

public class 박쥐 extends 포유류 {
	박쥐() {
		myClass = "박쥐";
	}
}