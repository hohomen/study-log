package inheritance01;

public class 고래 extends 포유류 {
	고래() {
		myClass = "고래";
	}
}