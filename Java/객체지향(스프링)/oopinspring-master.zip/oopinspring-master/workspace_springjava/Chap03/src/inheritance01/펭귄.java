package inheritance01;

public class 펭귄 extends 조류 {
	펭귄() {
		myClass = "펭귄";
	}
}