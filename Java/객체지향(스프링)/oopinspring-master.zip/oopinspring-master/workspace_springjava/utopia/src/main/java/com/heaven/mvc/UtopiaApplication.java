package com.heaven.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UtopiaApplication {

    public static void main(String[] args) {
        SpringApplication.run(UtopiaApplication.class, args);
    }
}
